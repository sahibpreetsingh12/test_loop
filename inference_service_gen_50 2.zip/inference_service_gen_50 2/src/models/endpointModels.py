from pydantic import BaseModel, constr,Field
from pydantic_settings import BaseSettings

class LLMInferenceRequest(BaseModel):
    
    user_query: str
    llm_model: str          #TODO: Add this value to config
    device: str  # CPU

class LLMInferenceResponse(BaseModel):
    sql_query: str

class RegenerateSQLRequest(BaseModel):
    sql_error: str = Field(..., max_length=40)
    erroneous_sql_query: str


