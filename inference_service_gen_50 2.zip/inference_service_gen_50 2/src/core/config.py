
from pydantic_settings import BaseSettings, SettingsConfigDict
from functools import lru_cache
import torch

def get_default_device():
    return "cuda" if torch.cuda.is_available() else "cpu"
    #return "cpu"

class Settings(BaseSettings):
    DB_HOST: str
    DB_USER: str
    DB_PASSWORD: str
    DB_NAME: str
    HOST: str = "0.0.0.0"
    PORT: int = 8000
    DEBUG_MODE: bool = True
    MAX_FEEDBACK_ATTEMPTS: int = 3
    SQL_MODEL_NAME: str = "ibm-granite/granite-3b-code-instruct"
    HARDWARE_DEVICE: str = get_default_device()

    model_config = SettingsConfigDict(env_file=".env", case_sensitive=False, extra="ignore")

@lru_cache()
def get_settings() -> Settings:
    return Settings()

settings = get_settings()
