from fastapi import FastAPI,Depends
from src.core.config import Settings, get_settings
import requests, os
import logging.config
import logging
from src.models.endpointModels import LLMInferenceRequest, LLMInferenceResponse,RegenerateSQLRequest
from src.utils.sqlModelInference import SQLInference

# Load the logging configuration
log_config_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'logging.conf')
logging.config.fileConfig(log_config_path, disable_existing_loggers=False)
logger = logging.getLogger('fastapi')


# Create FastAPI app
app = FastAPI(title="Inference Service")
sql_inference = SQLInference()

# # Initialize ConfigService
# config_service = ConfigService()
# config_service.load_config_from_mongo()

# Define route handlers
@app.get("/health", tags=["healthcheck"])
def health():
    logger.info("Health check endpoint was called.")
    return {"status": "Inference Service is healthy"}

@app.get("/", tags=["healthcheck"])
def index(settings: Settings = Depends(get_settings)):
    logger.info(f"Index endpoint was called. Debug mode: {settings.DEBUG_MODE}")
    return {"message": f"Hello from Inference Service! Debug mode: {settings.DEBUG_MODE}"}

# TODO: Move to routes according to project structure
@app.get("/generateSQLQuery",tags=["inference"], response_model=LLMInferenceResponse)
def generateSQLQuery(request:LLMInferenceRequest):
    user_query = request.user_query
    sql_query = sql_inference.generate_sql_query(user_query)
    print('sql query is ',sql_query)
    return LLMInferenceResponse(sql_query=sql_query)

@app.get("/regenerateSQLQuery",tags=["inference"])
def regenerate_sql_query(request: RegenerateSQLRequest, settings: Settings = Depends(get_settings)):        # Feedback loop
    improved_sql_query = sql_inference.regenerate_sql_query(request.sql_error, request.erroneous_sql_query)
    print(improved_sql_query)
    return improved_sql_query




if __name__ == "__main__":
    import uvicorn
    settings = get_settings()
    uvicorn.run(
        "app:app",
        host=settings.HOST,
        port=settings.PORT,
        reload=settings.DEBUG_MODE
    )
# Register service
# config_service.register_service('inference-service', 5004)
# logger.info("Inference Service has been registered with config service.")

# Additional logging if needed
logger.info("Inference Service has started.")
