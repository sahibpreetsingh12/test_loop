from pydantic_settings import BaseSettings, SettingsConfigDict
from functools import lru_cache
import torch
from typing import ClassVar,Any

def get_default_device():
    dev_ice = "cuda" if torch.cuda.is_available() else "cpu"
    print(dev_ice)
    return dev_ice
    

class Settings(BaseSettings):
    DB_HOST: str
    DB_USER: str
    DB_PASSWORD: str
    DB_NAME: str
    HOST: str = "0.0.0.0"
    PORT: int = 8000
    DEBUG_MODE: bool = True
    MAX_FEEDBACK_ATTEMPTS: int = 3
    SQL_MODEL_NAME: str = "defog/llama-3-sqlcoder-8b"
    HARDWARE_DEVICE: str = get_default_device()

    model_config = SettingsConfigDict(env_file=".env", case_sensitive=False, extra="ignore")
    # model_config: ClassVar[SettingsConfigDict] = SettingsConfigDict(
    #     env_file=".env",
    #     case_sensitive=False,
    #     extra="ignore",
    # )

    # @classmethod
    # def create(cls, **values: Any) -> "Settings":
    #     instance = cls(**values)
    #     instance.HARDWARE_DEVICE = get_default_device()
    #     return instance

@lru_cache()
def get_settings() -> Settings:
    return Settings()

settings = get_settings()
