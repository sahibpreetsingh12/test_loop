from pydantic import BaseModel, constr,Field
from pydantic_settings import BaseSettings

class LLMInferenceRequest(BaseModel):
    from src.core.config import settings
    user_query: str
    llm_model: str = settings.SQL_MODEL_NAME          #TODO: Add this value to config
    device: str = settings.HARDWARE_DEVICE # CPU

class LLMInferenceResponse(BaseModel):
    sql_query: str

class RegenerateSQLRequest(BaseModel):
    sql_error: str = Field(..., max_length=40)
    erroneous_sql_query: str

# class Settings(BaseSettings):
#     SQL_MODEL_NAME: str
#     HARDWARE_DEVICE: str        #CPU/GPU
#     DEBUG_MODE: bool = True

#     class Config:
#         env_file = ".env"

# settings = Settings()