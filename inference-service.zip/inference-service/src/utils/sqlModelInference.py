import torch, os, functools,logging
from transformers import AutoModelForCausalLM, AutoTokenizer
from .promptTemplate import PromptTemplate
from .SQLModelDownloader import SQLModelDownloader
logger = logging.getLogger('fastapi')

# Call limiter decorator
def call_limit(threshold):
    def decorator(func):
        # Track the number of calls
        calls = {"count": 0}
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            if calls["count"] >= threshold:
                raise Exception(f"Function call limit of {threshold} exceeded")
            calls["count"] += 1
            return func(*args, **kwargs)
        return wrapper
    return decorator
    # 

class SQLInference:
    def __init__(self):
        from src.core.config import settings
        # Initialize SQLModelDownloader
        model_downloader = SQLModelDownloader()

        self.device = settings.HARDWARE_DEVICE

        potential_path = os.getcwd()+'/'

        if os.path.exists(os.path.join(potential_path, "sql_model/config.json")):
          
          self.sql_model_dir = os.path.join(potential_path, "sql_model/")
          logger.info(f"Loading Model from {self.sql_model_dir}")
          self.sql_model = AutoModelForCausalLM.from_pretrained(self.sql_model_dir, local_files_only=True )
        else:

          logger.info("Model not found locally. Downloading...")
          self.sql_model = model_downloader._download_model()


        if os.path.exists(os.path.join(potential_path, "sql_tokenizer/tokenizer_config.json")):
           
           self.sql_tokenizer_dir = os.path.join(potential_path, "sql_tokenizer/")
           logger.info(f"Loading Tokenizer from {self.sql_tokenizer_dir}")
           self.sql_tokenizer = AutoTokenizer.from_pretrained(self.sql_tokenizer_dir, local_files_only=True)

        else:
           logger.info("Tokenizer not found locally. Downloading...")
           self.sql_tokenizer = model_downloader._download_tokenizer()

        self.sql_model.to(self.device)
        self.max_new_tokens = 200

        # self.sql_model_dir = os.getcwd() + "/sql_model/"            #TODO: Move to env config 
        # self.sql_tokenizer_dir = os.getcwd() + "/sql_tokenizer/"     #TODO: Move to env config 
        # self.sql_model = AutoModelForCausalLM.from_pretrained(str(self.sql_model_dir), local_files_only=True)        # TODO: Add variables to env config
        # self.sql_tokenizer = AutoTokenizer.from_pretrained(str(self.sql_tokenizer_dir), local_files_only=True)
        # self.max_new_tokens = 100
        

    def generate_sql_query(self,user_query:str):
        table_schema = self._get_table_schema()          # TODO: Call from SQL Connector to MongoDB endpoint
        _prompt_parameters = {"table_schema":table_schema,"user_query":user_query}
        prompt_template = PromptTemplate(**_prompt_parameters)
        generate_sql_query_prompt = prompt_template.generate_sql_query_template()
        chat = [{"role":"user", "content":generate_sql_query_prompt}]
        print('chat for generate is -->',chat)
        chat = self.tokenizer.apply_chat_template(chat, tokenize=False, add_generation_prompt=True)
        input_tokens = self.tokenizer(chat, return_tensors="pt")
        for i in input_tokens:
            input_tokens[i] = input_tokens[i].to(self.device)
        output = self.sql_model.generate(**input_tokens, max_new_tokens=self.max_new_tokens)
        output = self.sql_tokenizer.batch_decode(output)
        sql_query = output                                          # TODO:print(i) for i in output: Test the output on AWS instance or Google Colab
        return sql_query
    
    @call_limit(threshold=3)                                # TODO: Make hardcoded as env varible config
    def regenerate_sql_query(self,sql_error:str,erroneous_sql_query:str):       
        table_schema = self._get_table_schema()               # TODO: Call from SQL Connector to obtain table schema. This will be replaced with vectorDB reranker endpoint in v2.
        _prompt_parameters = {"available_sql_query":erroneous_sql_query,"sql_error":sql_error, "table_schema":table_schema}
        # regenerate_sql_query_prompt = PromptTemplate.regenerate_error_sql_query_template(**_prompt_parameters)
        prompt_template = PromptTemplate(**_prompt_parameters)
        regenerate_sql_query_prompt = prompt_template.regenerate_error_sql_query_template()
        
        chat = [{"role":"user", "content":regenerate_sql_query_prompt}]
        print('chat for regenrate is ',regenerate_sql_query_prompt)

        chat = self.tokenizer.apply_chat_template(chat, tokenize=False, add_generation_prompt=True)
        input_tokens = self.tokenizer(chat, return_tensors="pt")
        for i in input_tokens:
            input_tokens[i] = input_tokens[i].to(self.device)
        output = self.sql_model.generate(**input_tokens, max_new_tokens=self.max_new_tokens)
        output = self.sql_tokenizer.batch_decode(output)
        updated_sql_query = output  
        updated_sql_query = updated_sql_query[0].split("```sql")[2].split("\n")[1]      
        return updated_sql_query
    
    def _get_table_schema(self):
        return """
        CREATE TABLE Employees (
            EmployeeID INT PRIMARY KEY,
            FirstName VARCHAR(50),
            LastName VARCHAR(50),
            Email VARCHAR(100),
            Department VARCHAR(50),
            Position VARCHAR(50),
            Salary DECIMAL(10, 2)
        );

        CREATE TABLE EmployeeDetails (
            EmployeeID INT PRIMARY KEY,
            BirthDate DATE,
            Address VARCHAR(100),
            City VARCHAR(50),
            State VARCHAR(50),
            ZipCode VARCHAR(20),
            Phone VARCHAR(20),
            FOREIGN KEY (EmployeeID) REFERENCES Employees(EmployeeID)
        );
        """




