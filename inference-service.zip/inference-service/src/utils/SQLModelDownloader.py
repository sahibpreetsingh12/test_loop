import os, torch
import logging
import logging.config
from transformers import AutoModelForCausalLM, AutoTokenizer
from typing import Dict

# Load the logging configuration
log_config_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'logging.conf')
logging.config.fileConfig(log_config_path, disable_existing_loggers=False)


logger = logging.getLogger('fastapi')
class SQLModelDownloader:

    def __init__(self):
        from src.core.config import settings  
        self.device = settings.HARDWARE_DEVICE
        self.model_name = settings.SQL_MODEL_NAME            #TODO: Add to config
        self.sql_model_dir = self._create_model_dir(os.getcwd())
        self.sql_tokenizer_dir = self._create_tokenizer_dir(os.getcwd())
        _ = self._download_tokenizer()
        _ = self._download_model()


    def _create_model_dir(self,project_dir):
      model_dir =  project_dir + "/sql_model/"
      if not os.path.exists(model_dir):
    # Create the directory
          os.makedirs(model_dir)
          logger.info(f"Model directory '{model_dir}' created.")
      else:
          logger.info(f"Model directory '{model_dir}' already exists.")
      return model_dir

    def _create_tokenizer_dir(self,project_dir):
      tokenizer_dir =  project_dir + "/sql_tokenizer/"
      if not os.path.exists(tokenizer_dir):
        # Create the directory
          os.makedirs(tokenizer_dir)
          logger.info(f"Tokenizer directory '{tokenizer_dir}' created.")
      else:
          logger.info(f"Tokenizer directory '{tokenizer_dir}' already exists.")
      return tokenizer_dir

    def _download_tokenizer(self):
        if os.path.exists(os.path.join(self.sql_tokenizer_dir, "tokenizer_config.json")):
            logger.info(f"SQL Tokenizer found locally at {self.sql_tokenizer_dir}")
            return None
        else:
            print(f"Tokenizer not found locally. Downloading from {self.model_name}...")
            tokenizer = AutoTokenizer.from_pretrained(self.model_name)
            tokenizer.save_pretrained(str(self.sql_tokenizer_dir))
            logger.info(f"Tokenizer saved to {self.sql_tokenizer_dir}")
            return tokenizer

    def _download_model(self):
        if os.path.exists(os.path.join(self.sql_model_dir, "config.json")):
            print(f"SQL model found locally at {self.sql_model_dir}")
            return None
        else:
            print(f"Model not found locally. Downloading from {self.model_name}...")
            model = AutoModelForCausalLM.from_pretrained(self.model_name)
            model.save_pretrained(str(self.sql_model_dir))
            logger.info(f"Model saved to {self.sql_model_dir}")
            return model
                
if __name__ == "__main__":
    _ = SQLModelDownloader()
